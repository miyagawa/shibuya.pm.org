package MyWiki;

use strict;
use Catalyst qw/-Debug FillInForm Charsets::Japanese FormValidator
                  Authentication::Simple Session::FastMmap/;

use MyWiki::Parser;

our $VERSION = '0.01';

use constant ROOT_DIR => '/home/ktat/cvs/MyWiki2/MyWiki/root/';
use constant BASE_URL => 'http://localhost/sample/mywiki.cgi/';
use constant WIKI_FORMAT => 'kwiki'; # if empty, use yukiwiki

MyWiki->config(
               name => 'MyWiki',
               root => ROOT_DIR,
               base => BASE_URL,
               charsets => 'UTF-8',
               authentication => {user_file => ROOT_DIR . 'password'},
              );

MyWiki->setup;

sub end : Private { # TT, FillInForm�Τ�����ɲ�
  my ( $self, $c ) = @_;
  my $path = $ENV{PATH_INFO};
  $path =~ s{/.+?$}{/};  $path =~ s{^/$}{};
  $c->stash->{template} ||= $path . $c->req->{action} . '.tt';
  $c->forward('MyWiki::V::TT');
  $c->fillform($c->stash->{data});
  $c->res->{body} = "<html><head><title>" . $c->config->{name}
    ."</title></head><body>" . $c->res->{body} . "</body></html>";
}

sub default : Private {
  my ( $self, $c ) = @_;
  if(my $title = $c->req->params->{'title'} || 'FrontPage'){
    $c->wikidata_to_stash_from_title($title, 'data');
    my $p = new MyWiki::Parser(WIKI_FORMAT);
    $c->stash->{data}->{contents} =~s /^\+//mg;
    $c->stash->{data}->{contents} =~s /^\#.+//mg;
    $c->stash->{data}->{contents} = $p->parse_wiki($c->stash->{data}->{contents});
  }
  if(my $wikis = MyWiki::M::CDBI::Wiki->retrieve_all()){
    $c->stash->{titles} = [];
    my $wiki;
    push @{$c->stash->{titles}}, $wiki->title while $wiki = $wikis->next;
  }
}

sub wikidata_to_stash_from_title{
  my( $c, $title, $stash_key) = @_;
  die('need title and stash_key') unless $stash_key and $title;
  if(my $data = MyWiki::M::CDBI::Wiki->retrieve(title => $title)){
    $c->stash->{$stash_key}->{$_} = $data->$_  foreach qw/title contents/;
  }
}

sub edit : Global {
  my ( $self, $c ) = @_;
  $c->stash->{title} = $c->req->params->{'title'};
  $c->wikidata_to_stash_from_title($c->stash->{title}, 'data');
}

sub save : Global {
  my ( $self, $c ) = @_;
  my $title = $c->req->params->{'title'};
  my $contents = $c->req->params->{'contents'};
  unless(my $wiki = MyWiki::M::CDBI::Wiki->retrieve(title => $title)){
    MyWiki::M::CDBI::Wiki->create({title => $title, contents => $contents});
  }else{
    $wiki->contents($contents);
  }
  $c->res->redirect($c->config->{base} . '?title=' . $title);
}

sub login_to_admin : Global {
  my ( $self, $c ) = @_;
  $c->stash->{message} = 'ID or Password is/are wrong.' if $c->req->params->{'user'};
  $c->stash->{template} = 'login_to_admin.tt';
}

sub do_login : Global {
  my ( $self, $c ) = @_;
  my $user = $c->req->params->{'user'};
  my $password = $c->req->params->{'password'};
  unless ($c->session_login($user, $password)){
    $c->forward('login_to_admin');
  } else {
    $c->session->{user} = $user;
    $c->res->redirect( $c->config->{base} . 'admin');
  }
}

=head1 NAME

MyWiki - Catalyst based simple Wiki

=head1 SYNOPSIS

    script/mywiki_server.pl

=head1 DESCRIPTION

MyWiki is simple Wiki.
It can only create/modify page.
It doesn't have system which automaticaly link other page.
Wiki Format use Kwiki format.

You can change format with modifing MyWiki::Parser.

Note that: when you use this application on your server,
you need to change constant, ROOT_DIR and BASE_URL in MyWiki.pm.

=head1 Author

 Ktat <atusi@pure.ne.jp>

=head1 Copyright

 Copyright 2005 by Ktat <atusi@pure.ne.jp>.

 This program is free software; you can redistribute it
 and/or modify it under the same terms as Perl itself.

 See http://www.perl.com/perl/misc/Artistic.html

=cut

1;
