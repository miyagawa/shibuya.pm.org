package MyWiki::Parser;

use strict;
use warnings 'all';

sub new{
  my($class, $format) = @_;
  $format = '_wfmt_' . $format;
  $format = '_wfmt_yukiwiki'  unless $format and $class->can($format);
  bless {
	 format => $format,
	 code =>
	 {
	  dtdd  => \&_code_dtdd,
	  table => \&_code_table,
	 }
	}, $class;
}

sub set_code{
  my($self, $name, $code);
  $self->{code}->{$name} = $code;
}

{
  my $style =
    wikifmt
      (
       'i'     => "''(.+?)''",
       'u'     => "__(.+?)__",
       's'     => "==(.+?)==",
       'h1'    => '^\!\!\!([^!])',
       'h2'    => '^\!\!([^!])',
       'h3'    => '^\!([^!])',
       'pre'   => '^\s',
       'ol3'   => '^\+\+\+([^+])',
       'ol2'   => '^\+\+([^+])',
       'ol1'   => '^\+([^+])',
       'dd'    => '^:::([^:])',
       'dt'    => '^::([^:])',
       'ul3'   => '^\*\*\*([^*])',
       'ul2'   => '^\*\*([^*])',
       'ul1'   => '^\*([^*])',
       'hr'    => '^----',
       'dtdd'  => '^:(.+:.+)',
       'table' => '^,(.+)',
       'eow'   => "\t",
       'p'     => '^',
      );
  sub _wfmt_yukiwiki{
    return $style;
  }
}

{
  my $style =
    wikifmt
      (
       'i'     => '\s/(.+?)/\s',
       'u'     => '\s_(.+?)_\s',
       'h4'    => '^========\s',
       'h3'    => '^======\s',
       'h2'    => '^====\s',
       'h1'    => '^==\s',
       'pre'   => '^ ',
       'ol3'   => '^000\s',
       'ol2'   => '^00\s',
       'ol1'   => '^0\s',
       'ul3'   => '^\*\*\*\s',
       'ul2'   => '^\*\*\s',
       'ul1'   => '^\*\s',
       'hr'    => '^----',
       'table' => '^,(.+)',
       'eow'   => '^\t$',
       'p'     => '^',
      );
  sub _wfmt_kwiki{
    return $style;
  }
}

sub wikifmt{
  my @name = @_;
  my %name = @name;
  my $style =
    {
     'i' => {tag => 'i'},
     'u' => {tag => 'u'},
     's' => {tag => 's'},
     'h1' => {tag =>'h1'},
     'h2' => {tag => 'h2'},
     'h3'   => {tag => 'h3'},
     'h4'   => {tag => 'h4'},
     'pre'   => {tag => '', markstart => 'pre', suffix => "\n", suffix_force => 1},
     'ol3' => {tag => '', markstart => ['ol', 'li'], can_nest => 1, tag4repeat => '/li><li'},
     'ol2' => {tag => '', markstart => ['ol', 'li'], can_nest => 1, tag4repeat => '/li><li'},
     'ol1'   => {tag => '', markstart => ['ol', 'li'], endtag => '', tag4repeat => '/li><li'},
     'dd'  => {tag => 'dd', markstart => '-', endtag => '', tag4repeat => '', can_nest => 1},
     'dt'   => {tag => 'dt', markstart => 'dl', endtag => '', lendtag => 'dd'},
     'ul3' => {tag => '', markstart => ['ul', 'li'], can_nest => 1, tag4repeat => '/li><li'},
     'ul2'   => {tag => '', markstart => ['ul', 'li'], can_nest => 1, tag4repeat => '/li><li'},
     'ul1'     => {tag => '', markstart => ['ul', 'li'], endtag => '', tag4repeat => '/li><li'},
     'hr' => {tag => 'div style="page-break-before: always;"><hr', endtag => ''},
     'dtdd' => {code => 'dtdd', codelast => 0},
     'table' => {tag => 'tr', markstart => 'table', code => 'table'},
     'eow' => {},
     'p' => {tag => '', markstart => 'p', suffix => '<br>', tag4repeat => ''},
    };
  $style->{ol3}->{can_nest} = $style->{ol2};
  $style->{ol2}->{can_nest} = $style->{ol1};
  $style->{ul3}->{can_nest} = $style->{ul2};
  $style->{ul2}->{can_nest} = $style->{ul1};
  $style->{dd}->{can_nest}  = $style->{dt};
  return [ map{$name[$_ + 1] => $style->{$name[$_]}}(map $_ % 2 ? () : $_, (0.. $#name)) ];
}

sub _code_table{
  my($self, $line) = @_;
  my @cel = split /,/, $line;
  return "<td>" . join('</td><td>', @cel) . "</td>";
}

sub _code_dtdd{
  my($self, $line) = @_;
  my($key, $explain) = split /:/, $line, 2;
  return "<dl><dt>$key</dt><dd>$explain</dd></dl>";
}


sub parse_wiki{
  my($self, $text) = @_;
  my $format = $self->{format};
  my $style = $self->$format;
  my @mark;
  $text =~ s/\t/    /g;
  $text =~s/\x0D\x0A|\x0D|\x0A/\n/sg;
  my @text = split /\n/, $text;
  push @text, "\t"; # for eow
 LOOP: foreach my $n (0 .. $#text){
    my $o_line = '';
    my $line = $o_line = $text[$n];
    $line =~s|<|&lt;|g; $line =~s|>|&gt;|g;
  STYLE: for(my $i = 0; $i < @$style; $i += 2){
      my($regex, $p) = @$style[$i, $i + 1];
      my($ptag, $pmark, $endp) = ($p->{tag} || '', $p->{markstart} || '', undef);
      $regex and $line and $line =~/$regex/;
      if($regex and $regex !~/^\^/){ # inline
        my $pl = $line;
        $line =~s#$regex#<$ptag>$1</$ptag>#g;
        next STYLE;
      }elsif($regex and $line =~s/$regex/$1 || ''/e){ # block;
        my(@prefix, @suffix) = ();
        if(my $code = $p->{code} and $p->{codelast}){
          $line = $self->{code}->{$code}->($self, $1);
        }else{
          $line = $self->{code}->{$code}->($self, $1) if $code;
	  if(defined $p->{suffix} and ((defined $p->{suffix_force} and $p->{suffix_force}) or $o_line !~/^\s*$/)){
	    $line .= $p->{suffix};
	  }
          my $endtag = $p->{endtag};
	  $mark[$#mark]->{can_nest} ||= '' if @mark;
	  $p->{can_nest} ||= '';
          if(defined $pmark and $pmark){
            if(@mark and $mark[$#mark]->{can_nest} eq $p){# �Ҥ���ƤΤȤ������褿
              my $endp = pop @mark;
              push @prefix, "</$p->{lendtag}>" if $p->{lendtag};
              if($endp->{markstart} ne '-' and not defined $endp->{markend}){
                push @prefix, map "</$_>", ref $endp->{markstart} ? reverse @{$endp->{markstart}} : $endp->{markstart}
              }
              push @prefix, "</$endp->{tag}>" if $endp->{tag} and not defined $endp->{endtag};
              # �Ҥ���Ƥξ���ľ���markstart�������Ĥ������ȳ��������˻Ȥ��Ф褤
              push @prefix, map "</$_><$_>", ref $p->{markstart} ? (reverse @{$p->{markstart}})[0] : $p->{markstart};
            }elsif(@mark and $mark[$#mark] eq $p->{can_nest} || ''){# �Ƥ���Ҥ�
              push @mark, $p;
              push @prefix, "</$p->{lendtag}>" if $p->{lendtag};
              push @prefix, map "<$_>", ref $pmark ? @{$pmark} : $pmark if $pmark ne '-';
            }elsif(@mark and $mark[$#mark] eq $p){# Ʊ���Ȥ���
              if(defined $mark[$#mark]->{tag4repeat}){
                $ptag = $mark[$#mark]->{tag4repeat};
                $endtag = '';
              }elsif($p->{lendtag}){
                push @prefix, "</$p->{lendtag}>";
              }
            }else{ # �̤Υ���
              while($endp = pop @mark){
                push @prefix, "\n</$endp->{tag}>" if $endp->{tag} and not defined $endp->{endtag};
                if($endp->{markstart} ne '-' and not defined $endp->{markend}){
                  push @prefix, map "\n</$_>", ref $endp->{markstart} ? reverse @{$endp->{markstart}} : $endp->{markstart}
                }
              }
              push @mark, $p;
              push @prefix, map "\n<$_>", ref $pmark ? @{$pmark} : $pmark if $pmark ne '-';
            }
          }else{
            while($endp = pop @mark){
              if($endp->{markstart} ne '-' and not defined $endp->{markend}){
                push @prefix, map "\n</$_>", ref $endp->{markstart} ? reverse @{$endp->{markstart}} : $endp->{markstart}
              }
            }
          }
          if($ptag){
            push @prefix, "<$ptag>";
            unshift @suffix, "</$ptag>" unless defined $endtag;
          }
        }
        $text[$n] = join '', @prefix, $line, @suffix;
        next LOOP;
      }
    }
  }
  my $result = join("", @text);
  return $result;
}

=head1 NAME

MyWiki::Parser - Wiki Parser

=head1 SYNOPSIS

 my $wiki = MyWiki::Parser->new()
      # default is yuki wiki format
 my $wiki = MyWiki::Parser->new('kwiki');
      # you can use kwiki format
 
 my $result = $wiki->parse_wiki($data);
 
 print $result;

=head1 DESCRIPTION

This module is for me to create my own simple wiki format with simple RegExp.
This module support YukiWiki format and Kwiki format(for Spork).
Their implemntation in this module is not perfect.
I won't make it perfect and I think this module cannot.

Note that: This code is very dirty. So I recommend for you *not* to read code.

=head1 How to define your Wiki format

Add a function in MyWiki::Parser namespace.
The function name have to be started from '_wfmt_', for example _wfmt_yukiwiki.

exapmle:

 {
   my $style =
     wikifmt
       (
        'i'     => "''(.+?)''",
        'u'     => "__(.+?)__",
        's'     => "==(.+?)==",
        'h1'    => '^\!\!\!([^!])',
        'h2'    => '^\!\!([^!])',
        'h3'    => '^\!([^!])',
        'pre'   => '^\s',
        'ol3'   => '^\+\+\+([^+])',
        'ol2'   => '^\+\+([^+])',
        'ol1'   => '^\+([^+])',
        'dd'    => '^:::([^:])',
        'dt'    => '^::([^:])',
        'ul3'   => '^\*\*\*([^*])',
        'ul2'   => '^\*\*([^*])',
        'ul1'   => '^\*([^*])',
        'hr'    => '^----',
        'dtdd'  => '^:(.+:.+)',
        'table' => '^,(.+)',
        'eow'   => "\t",
        'p'     => '^',
       );
   sub _wfmt_yukiwiki{
     return $style;
   }
 }

In the block out of _wfmt_yukiwiki subroutine,
an array is passed to wikifmt function.

This array likes hash. Key is tag name and value is RegExp.
If RegExp matches, line will be modified.
The order of key is very important.
Inline decoration is former, block decoration is later.

If you use parenthese in RegExp, This is used as string after tag.

=head2 Special keys

=over 4

=item eow

eow is end of wiki.

 'eow' => '\t',

must not change it.

=item dtdd, table

Tag, dt, dd and table are some difficult with only RegExp.
I write code for these. but, it is for yukiwiki only.
You may set your code for other format using set_code method.

=back

=head2 Supported Tags

     i
     u
     s
     h1
     h2
     h3
     h4
     pre
     ol -- until 3 depth
     dd
     dt
     ul -- until 3 depth
     hr
     dtdd
     table
     eow
     p

=head1 Method

=over 4

=item new

 $wiki = MyWiki::Parser->new('format');

=item set_code

 $wiki->set_code('table' => $sub_ref);
 $wiki->set_code('dtdd'  => $sub_ref2);

example of subroutine reference;

 my $sub_ref = sub {
   my($self, $line) = @_;
   my @cel = split /,/, $line;
   return "<td>" . join('</td><td>', @cel) . "</td>";
 }

=item parse_wiki

 $result = $wiki->parse_wiki($text);

Parse plain text and create formatted text.

=back

=head1 Author

 Ktat <atusi@pure.ne.jp>

=head1 Copyright

 Copyright 2005 by Ktat <atusi@pure.ne.jp>.

 This program is free software; you can redistribute it
 and/or modify it under the same terms as Perl itself.

 See http://www.perl.com/perl/misc/Artistic.html

=cut

1;
